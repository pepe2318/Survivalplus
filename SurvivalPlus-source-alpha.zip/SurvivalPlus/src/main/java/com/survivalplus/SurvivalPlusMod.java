package com.survivalplus;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

import static net.minecraft.server.command.CommandManager.argument;
import static net.minecraft.server.command.CommandManager.literal;

public class SurvivalPlusMod implements ModInitializer {
    private static final Map<UUID, UUID> PENDING_TPA = new ConcurrentHashMap<>();

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(literal("tpa")
                .then(argument("jugador", StringArgumentType.word()).executes(context -> {
                    ServerPlayerEntity requester = context.getSource().getPlayerOrThrow();
                    String name = StringArgumentType.getString(context, "jugador");
                    ServerPlayerEntity target = context.getSource().getServer().getPlayerManager().getPlayer(name);
                    if (target == null) {
                        context.getSource().sendError(Text.literal("Ese jugador no está conectado."));
                        return 0;
                    }
                    if (target.getUuid().equals(requester.getUuid())) {
                        context.getSource().sendError(Text.literal("No podés enviarte una solicitud a vos mismo."));
                        return 0;
                    }
                    PENDING_TPA.put(target.getUuid(), requester.getUuid());
                    target.sendMessage(Text.literal(requester.getName().getString() + " te envió una solicitud de teletransportación. Usá /tpaccept para aceptar o /tpdeny para rechazar."), false);
                    requester.sendMessage(Text.literal("Solicitud enviada a " + target.getName().getString() + "."), false);
                    return 1;
                })));

            dispatcher.register(literal("tpaccept").executes(context -> {
                ServerPlayerEntity target = context.getSource().getPlayerOrThrow();
                UUID requesterId = PENDING_TPA.remove(target.getUuid());
                if (requesterId == null) {
                    target.sendMessage(Text.literal("No tenés solicitudes pendientes."), false);
                    return 0;
                }
                ServerPlayerEntity requester = context.getSource().getServer().getPlayerManager().getPlayer(requesterId);
                if (requester == null) {
                    target.sendMessage(Text.literal("El jugador que envió la solicitud ya no está conectado."), false);
                    return 0;
                }
                requester.teleport(
                    (ServerWorld) target.getEntityWorld(),
                    target.getX(),
                    target.getY(),
                    target.getZ(),
                    Set.of(),
                    requester.getYaw(),
                    requester.getPitch(),
                    false
                );
                requester.sendMessage(Text.literal("Tu solicitud fue aceptada."), false);
                target.sendMessage(Text.literal("Teletransportaste a " + requester.getName().getString() + "."), false);
                return 1;
            }));

            dispatcher.register(literal("tpdeny").executes(context -> {
                ServerPlayerEntity target = context.getSource().getPlayerOrThrow();
                UUID requesterId = PENDING_TPA.remove(target.getUuid());
                if (requesterId == null) {
                    target.sendMessage(Text.literal("No tenés solicitudes pendientes."), false);
                    return 0;
                }
                ServerPlayerEntity requester = context.getSource().getServer().getPlayerManager().getPlayer(requesterId);
                if (requester != null) requester.sendMessage(Text.literal(target.getName().getString() + " rechazó tu solicitud."), false);
                target.sendMessage(Text.literal("Solicitud rechazada."), false);
                return 1;
            }));
        });
    }
}
