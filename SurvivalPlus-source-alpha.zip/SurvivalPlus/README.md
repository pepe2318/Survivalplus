# SurvivalPlus (Minecraft 1.21.10 / Fabric)

Proyecto inicial con estructura Gradle/Fabric y comandos TPA (`/tpa`, `/tpaccept`, `/tpdeny`).

## Importante
Esta es la **base inicial**, no la versión completa del mod: el sistema de lápidas todavía debe implementarse y probarse antes de instalarlo en un servidor. No uses todavía el JAR en producción.

## Compilar
Requiere Java 21 y Gradle 8.14.3:

```bash
gradle build
```

El JAR se genera en `build/libs/`.

## Próxima etapa
Implementar lápidas persistentes con inventario completo, mapa localizador, protección contra duplicación y liberación de objetos al romperlas.
